import java.util.*;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) throw new IllegalArgumentException();
        contacts.put(contact.getContactId(), contact);
    }

    public void deleteContact(String id) { contacts.remove(id); }

    public void updateContact(String id, String first, String last, String phone, String address) {
        Contact c = contacts.get(id);
        if (c == null) throw new IllegalArgumentException();
        c.setFirstName(first);
        c.setLastName(last);
        c.setPhone(phone);
        c.setAddress(address);
    }
}