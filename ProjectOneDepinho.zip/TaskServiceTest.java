import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
@Test void serviceOps(){
 TaskService s=new TaskService();
 Task t=new Task("1","A","B");
 s.addTask(t);
 s.updateTask("1","C","D");
 s.deleteTask("1");
}
@Test void duplicate(){
 TaskService s=new TaskService();
 Task t=new Task("1","A","B");
 s.addTask(t);
 assertThrows(IllegalArgumentException.class,()->s.addTask(t));
}
}