import java.util.*;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task){
        if(tasks.containsKey(task.getTaskId())) throw new IllegalArgumentException();
        tasks.put(task.getTaskId(), task);
    }
    public void deleteTask(String id){ tasks.remove(id); }
    public void updateTask(String id,String name,String description){
        Task t=tasks.get(id);
        if(t==null) throw new IllegalArgumentException();
        t.setName(name);
        t.setDescription(description);
    }
}