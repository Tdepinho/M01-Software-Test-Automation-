import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {
@Test void addDelete(){
 AppointmentService s=new AppointmentService();
 Appointment a=new Appointment("1",new Date(System.currentTimeMillis()+100000),"Desc");
 s.addAppointment(a);
 s.deleteAppointment("1");
}
@Test void duplicate(){
 AppointmentService s=new AppointmentService();
 Appointment a=new Appointment("1",new Date(System.currentTimeMillis()+100000),"Desc");
 s.addAppointment(a);
 assertThrows(IllegalArgumentException.class,()->s.addAppointment(a));
}
}