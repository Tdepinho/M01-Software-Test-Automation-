import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {
@Test void valid(){
 assertNotNull(new Appointment("1", new Date(System.currentTimeMillis()+100000), "Desc"));
}
@Test void invalidDate(){
 assertThrows(IllegalArgumentException.class,()->new Appointment("1", new Date(System.currentTimeMillis()-1000), "Desc"));
}
@Test void invalidFields(){
 assertThrows(IllegalArgumentException.class,()->new Appointment(null,new Date(System.currentTimeMillis()+1000),"Desc"));
 assertThrows(IllegalArgumentException.class,()->new Appointment("1",new Date(System.currentTimeMillis()+1000),null));
}
}