import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {
@Test void valid(){ assertNotNull(new Task("1","Task","Desc")); }
@Test void invalids(){
 assertThrows(IllegalArgumentException.class,()->new Task(null,"a","b"));
 assertThrows(IllegalArgumentException.class,()->new Task("1",null,"b"));
 assertThrows(IllegalArgumentException.class,()->new Task("1","a",null));
}
@Test void setters(){
 Task t=new Task("1","A","B");
 t.setName("New");
 t.setDescription("NewDesc");
 assertEquals("New",t.getName());
}
}