import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
@Test void addDeleteUpdate(){
 ContactService s=new ContactService();
 Contact c=new Contact("1","A","B","1234567890","Addr");
 s.addContact(c);
 s.updateContact("1","C","D","0987654321","New");
 s.deleteContact("1");
}
@Test void duplicate(){
 ContactService s=new ContactService();
 Contact c=new Contact("1","A","B","1234567890","Addr");
 s.addContact(c);
 assertThrows(IllegalArgumentException.class,()->s.addContact(c));
}
}