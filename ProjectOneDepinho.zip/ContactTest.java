import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {
@Test void validContact(){ assertNotNull(new Contact("1","John","Doe","1234567890","Address")); }
@Test void badId(){ assertThrows(IllegalArgumentException.class,()->new Contact(null,"J","D","1234567890","A")); }
@Test void badFirst(){ assertThrows(IllegalArgumentException.class,()->new Contact("1",null,"D","1234567890","A")); }
@Test void badLast(){ assertThrows(IllegalArgumentException.class,()->new Contact("1","J",null,"1234567890","A")); }
@Test void badPhone(){ assertThrows(IllegalArgumentException.class,()->new Contact("1","J","D","1","A")); }
@Test void badAddress(){ assertThrows(IllegalArgumentException.class,()->new Contact("1","J","D","1234567890",null)); }
@Test void setters(){ Contact c=new Contact("1","J","D","1234567890","A"); c.setFirstName("Jane"); c.setLastName("Smith"); c.setPhone("0987654321"); c.setAddress("New"); assertEquals("Jane",c.getFirstName()); }
}